The images in this folder are referenced by the following themes: jqx.ui-lightness.css, jqx.ui-darkness.css, jqx.ui-le-frog.css, jqx.ui-overcast.css, jqx-ui-redmond.css, jqx-ui-smoothness.css, jqx-ui-start.css and jqx-ui-sunny.css.

The images are downloaded from http://jqueryui.com and are MIT Licensed.

