Download more cultures from: http://jqwidgets.com/builds/cultures.zip
License: https://github.com/jquery/globalize/blob/master/LICENSE
